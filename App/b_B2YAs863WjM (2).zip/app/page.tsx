"use client"

import { useState, useMemo } from "react"
import { Topbar } from "@/components/supppower/topbar"
import { ProgressBar } from "@/components/supppower/progress-bar"
import { PortionTabs } from "@/components/supppower/portion-tabs"
import { HeroCard } from "@/components/supppower/hero-card"
import { SupplementCard } from "@/components/supppower/supplement-card"
import { BottomBar } from "@/components/supppower/bottom-bar"
import { InfoSheet } from "@/components/supppower/info-sheet"
import { portions, getTotalSupplements, type Supplement } from "@/lib/supplements"

export default function SuppPowerOS() {
  const [activePortionId, setActivePortionId] = useState(portions[0].id)
  const [completedSupplements, setCompletedSupplements] = useState<Set<string>>(new Set())
  const [selectedSupplement, setSelectedSupplement] = useState<Supplement | null>(null)
  const [isSheetOpen, setIsSheetOpen] = useState(false)

  const activePortion = useMemo(() => 
    portions.find(p => p.id === activePortionId) || portions[0],
    [activePortionId]
  )

  const activePortionIndex = useMemo(() =>
    portions.findIndex(p => p.id === activePortionId),
    [activePortionId]
  )

  const totalSupplements = getTotalSupplements()
  const completedCount = completedSupplements.size
  
  const portionCompletedCount = useMemo(() =>
    activePortion.supplements.filter(s => completedSupplements.has(s.id)).length,
    [activePortion, completedSupplements]
  )

  const toggleSupplement = (id: string) => {
    setCompletedSupplements(prev => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  const resetPortion = () => {
    setCompletedSupplements(prev => {
      const next = new Set(prev)
      activePortion.supplements.forEach(s => next.delete(s.id))
      return next
    })
  }

  const resetDay = () => {
    setCompletedSupplements(new Set())
  }

  const markAllDone = () => {
    setCompletedSupplements(prev => {
      const next = new Set(prev)
      activePortion.supplements.forEach(s => next.add(s.id))
      return next
    })
  }

  const showSupplementInfo = (supplement: Supplement) => {
    setSelectedSupplement(supplement)
    setIsSheetOpen(true)
  }

  const showSummary = () => {
    alert(`Heute erledigt: ${completedCount} von ${totalSupplements} Supplements`)
  }

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Neon Green Gradient Background */}
      <div 
        className="fixed inset-0"
        style={{ 
          background: 'linear-gradient(135deg, #a8e063 0%, #56ab2f 25%, #2d5016 50%, #1a3009 75%, #0f1f05 100%)',
        }}
      />
      {/* Gradient overlay for depth */}
      <div 
        className="fixed inset-0"
        style={{ 
          background: 'radial-gradient(ellipse at top left, rgba(168, 224, 99, 0.4) 0%, transparent 50%), radial-gradient(ellipse at bottom right, rgba(45, 80, 22, 0.6) 0%, transparent 50%)',
        }}
      />
      {/* Grid overlay */}
      <div 
        className="pointer-events-none fixed inset-0 opacity-10"
        style={{
          background: 'linear-gradient(rgba(255,255,255,0.018) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.014) 1px, transparent 1px)',
          backgroundSize: '56px 56px',
          maskImage: 'radial-gradient(circle at center, black 34%, transparent 100%)'
        }}
      />
      
      {/* Content */}
      <div className="relative z-10 mx-auto max-w-md pb-32">
        <Topbar onShowSummary={showSummary} />
        
        <ProgressBar done={completedCount} total={totalSupplements} />
        
        <PortionTabs
          portions={portions}
          activePortionId={activePortionId}
          onPortionChange={setActivePortionId}
          completedSupplements={completedSupplements}
        />
        
        <HeroCard
          portion={activePortion}
          portionIndex={activePortionIndex}
          completedCount={portionCompletedCount}
        />
        
        <div className="px-5">
          <div className="mb-3 pl-0.5 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            SUPPLEMENTS
          </div>
          {activePortion.supplements.map(supplement => (
            <SupplementCard
              key={supplement.id}
              supplement={supplement}
              isDone={completedSupplements.has(supplement.id)}
              onToggle={() => toggleSupplement(supplement.id)}
              onShowInfo={() => showSupplementInfo(supplement)}
            />
          ))}
        </div>
      </div>
      
      <BottomBar
        onResetPortion={resetPortion}
        onResetDay={resetDay}
        onMarkAllDone={markAllDone}
      />
      
      <InfoSheet
        supplement={selectedSupplement}
        isOpen={isSheetOpen}
        onClose={() => setIsSheetOpen(false)}
      />
    </div>
  )
}
