"use client"

import { cn } from "@/lib/utils"
import { Wind } from "lucide-react"

interface AirConditionerCardProps {
  temperature: number
  room: string
  isOn: boolean
  onToggle: () => void
}

export function AirConditionerCard({ 
  temperature, 
  room, 
  isOn, 
  onToggle 
}: AirConditionerCardProps) {
  return (
    <div className="glass-light flex items-center justify-between rounded-2xl p-5">
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-3">
          <span className="text-base font-medium text-foreground">Air Conditioner</span>
          <button
            onClick={onToggle}
            className={cn(
              "flex h-7 w-12 items-center rounded-full p-1 transition-colors",
              isOn ? "bg-lime-500/80 justify-end" : "bg-white/10 justify-start"
            )}
          >
            <span
              className={cn(
                "h-5 w-5 rounded-full transition-colors",
                isOn ? "bg-white" : "bg-white/30"
              )}
            />
          </button>
        </div>
        
        <div className="mt-2">
          <span className="text-5xl font-light tracking-tight text-foreground">
            {temperature}°C
          </span>
          <p className="mt-1 text-sm text-muted-foreground">{room}</p>
        </div>
      </div>
      
      <div className="relative h-20 w-20">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative">
            <Wind className="h-16 w-16 text-blue-400/80" />
            <div className="absolute -right-2 -top-2 h-6 w-6 rounded-full bg-blue-500/30 blur-md" />
            <div className="absolute -bottom-1 -left-1 h-4 w-4 rounded-full bg-cyan-400/40 blur-sm" />
          </div>
        </div>
      </div>
    </div>
  )
}
