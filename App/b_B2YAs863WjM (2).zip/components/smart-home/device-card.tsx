"use client"

import { cn } from "@/lib/utils"

interface DeviceCardProps {
  icon: React.ReactNode
  title: string
  subtitle: string
  isOn: boolean
  onToggle: () => void
  isActive?: boolean
  className?: string
}

export function DeviceCard({
  icon,
  title,
  subtitle,
  isOn,
  onToggle,
  isActive = false,
  className,
}: DeviceCardProps) {
  return (
    <div
      className={cn(
        "relative flex flex-col justify-between rounded-2xl p-4 transition-all duration-300",
        isActive
          ? "glass-active text-white"
          : "glass-light text-card-foreground",
        className
      )}
    >
      <div className="flex items-start justify-between">
        <div className={cn(
          "flex h-10 w-10 items-center justify-center rounded-lg",
          isActive ? "bg-white/10" : "bg-white/5"
        )}>
          {icon}
        </div>
        <span className={cn(
          "text-sm font-medium",
          isOn ? "text-lime-400" : isActive ? "text-white/70" : "text-muted-foreground"
        )}>
          {isOn ? "On" : "Off"}
        </span>
      </div>
      
      <div className="mt-4">
        <h3 className="font-semibold">{title}</h3>
        <p className={cn(
          "text-sm",
          isActive ? "text-white/80" : "text-muted-foreground"
        )}>
          {subtitle}
        </p>
      </div>

      <button
        onClick={onToggle}
        className={cn(
          "mt-3 flex h-7 w-12 items-center rounded-full p-1 transition-colors",
          isOn 
            ? isActive ? "bg-white/90 justify-end" : "bg-lime-500/80 justify-end"
            : "bg-white/10 justify-start"
        )}
      >
        <span
          className={cn(
            "h-5 w-5 rounded-full transition-colors",
            isOn 
              ? isActive ? "bg-lime-500" : "bg-white"
              : "bg-white/30"
          )}
        />
      </button>
    </div>
  )
}
