"use client"

import { cn } from "@/lib/utils"
import { Plus } from "lucide-react"

interface RoomTabsProps {
  rooms: string[]
  activeRoom: string
  onRoomChange: (room: string) => void
}

export function RoomTabs({ rooms, activeRoom, onRoomChange }: RoomTabsProps) {
  return (
    <div className="glass flex items-center gap-2 rounded-full p-1.5">
      {rooms.map((room) => (
        <button
          key={room}
          onClick={() => onRoomChange(room)}
          className={cn(
            "flex items-center gap-2 rounded-full px-4 py-2.5 text-sm font-medium transition-colors",
            activeRoom === room
              ? "bg-white/10 text-foreground"
              : "text-muted-foreground hover:text-foreground hover:bg-white/5"
          )}
        >
          {activeRoom === room && (
            <span className="h-2 w-2 rounded-full bg-orange-500" />
          )}
          {room}
        </button>
      ))}
      <button className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-muted-foreground transition-colors hover:text-foreground hover:bg-white/10">
        <Plus className="h-4 w-4" />
      </button>
    </div>
  )
}
