"use client"

import { cn } from "@/lib/utils"
import { Home, LayoutGrid, Shield, Monitor, Wifi, Zap } from "lucide-react"

interface SidebarProps {
  activeItem: string
  onItemClick: (item: string) => void
}

const menuItems = [
  { id: "home", icon: Home },
  { id: "grid", icon: LayoutGrid },
  { id: "shield", icon: Shield },
  { id: "monitor", icon: Monitor },
  { id: "wifi", icon: Wifi },
  { id: "energy", icon: Zap },
]

export function Sidebar({ activeItem, onItemClick }: SidebarProps) {
  return (
    <aside className="glass flex flex-col items-center gap-2 rounded-2xl px-3 py-4">
      {menuItems.map((item) => {
        const Icon = item.icon
        const isActive = activeItem === item.id
        return (
          <button
            key={item.id}
            onClick={() => onItemClick(item.id)}
            className={cn(
              "flex h-12 w-12 items-center justify-center rounded-xl transition-colors",
              isActive
                ? "bg-white/10 text-foreground"
                : "text-muted-foreground hover:text-foreground hover:bg-white/5"
            )}
          >
            <Icon className={cn("h-5 w-5", item.id === "energy" && "text-orange-500")} />
          </button>
        )
      })}
    </aside>
  )
}
