"use client"

interface TemperatureGaugeProps {
  currentTemp: number
  minTemp?: number
  maxTemp?: number
}

export function TemperatureGauge({ 
  currentTemp, 
  minTemp = 10, 
  maxTemp = 30 
}: TemperatureGaugeProps) {
  const percentage = ((currentTemp - minTemp) / (maxTemp - minTemp)) * 100
  const angle = -90 + (percentage * 1.8)

  return (
    <div className="glass-light flex flex-col rounded-2xl p-4">
      <h3 className="text-sm font-medium text-foreground">Home Temp</h3>
      <p className="text-xs text-muted-foreground">
        {currentTemp}°C
        <span className="ml-2">Now</span>
      </p>
      
      <div className="relative mt-4 flex items-center justify-center">
        <svg viewBox="0 0 200 120" className="h-32 w-full">
          {/* Background arc */}
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="rgba(255, 255, 255, 0.1)"
            strokeWidth="12"
            strokeLinecap="round"
          />
          {/* Gradient arc */}
          <defs>
            <linearGradient id="tempGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#06b6d4" />
              <stop offset="100%" stopColor="#14b8a6" />
            </linearGradient>
          </defs>
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="url(#tempGradient)"
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={`${percentage * 2.5} 250`}
          />
          {/* Indicator dot */}
          <circle
            cx={100 + 80 * Math.cos((angle * Math.PI) / 180)}
            cy={100 + 80 * Math.sin((angle * Math.PI) / 180)}
            r="8"
            fill="#06b6d4"
            className="drop-shadow-lg"
          />
        </svg>
        
        <div className="absolute bottom-0 flex w-full justify-between px-2 text-xs text-muted-foreground">
          <span>{minTemp}°C</span>
          <span>{maxTemp}°C</span>
        </div>
      </div>
    </div>
  )
}
