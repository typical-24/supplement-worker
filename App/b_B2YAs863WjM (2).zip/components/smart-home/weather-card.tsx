"use client"

import { Cloud, Sun } from "lucide-react"

interface WeatherCardProps {
  time: string
  date: string
  temperature: number
  condition: string
}

export function WeatherCard({ time, date, temperature, condition }: WeatherCardProps) {
  return (
    <div className="glass-light flex flex-col rounded-2xl p-6">
      <div className="mb-6">
        <span className="text-5xl font-light tracking-tight text-foreground">{time}</span>
        <p className="mt-1 text-sm text-muted-foreground">{date}</p>
      </div>
      
      <div className="flex items-end justify-between">
        <div>
          <span className="text-3xl font-light text-foreground">{temperature}°C</span>
          <p className="mt-1 text-sm text-muted-foreground">{condition}</p>
        </div>
        <div className="relative">
          <Sun className="h-12 w-12 text-yellow-400" />
          <Cloud className="absolute -bottom-1 -left-2 h-10 w-10 text-gray-300" />
        </div>
      </div>
    </div>
  )
}
