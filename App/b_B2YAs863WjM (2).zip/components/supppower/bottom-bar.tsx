"use client"

import { cn } from "@/lib/utils"

interface BottomBarProps {
  onResetPortion: () => void
  onResetDay: () => void
  onMarkAllDone: () => void
}

export function BottomBar({ onResetPortion, onResetDay, onMarkAllDone }: BottomBarProps) {
  return (
    <div 
      className="fixed bottom-0 left-1/2 z-50 flex w-full max-w-md -translate-x-1/2 gap-2.5 px-5 pb-8 pt-4"
      style={{
        background: 'linear-gradient(to top, rgba(10, 30, 10, 0.96) 60%, transparent)',
        backdropFilter: 'blur(18px)',
        WebkitBackdropFilter: 'blur(18px)'
      }}
    >
      <button
        onClick={onResetPortion}
        className="glass flex-1 rounded-2xl border border-white/10 px-3 py-3 text-xs font-bold tracking-wide text-white/70 transition-all active:scale-95"
      >
        Reset Portion
      </button>
      <button
        onClick={onResetDay}
        className="glass flex-1 rounded-2xl border border-white/10 px-3 py-3 text-xs font-bold tracking-wide text-white/70 transition-all active:scale-95"
      >
        Reset Tag
      </button>
      <button
        onClick={onMarkAllDone}
        className="flex-1 rounded-2xl px-3 py-3 text-xs font-bold tracking-wide text-white transition-all active:scale-95"
        style={{
          background: 'linear-gradient(135deg, #4ade80 0%, #22c55e 48%, #16a34a 100%)',
          borderColor: 'rgba(255, 255, 255, 0.16)',
          boxShadow: '0 0 18px rgba(74, 222, 128, 0.38), 0 0 34px rgba(34, 197, 94, 0.18), inset 0 1px 0 rgba(255,255,255,0.16)'
        }}
      >
        Alle Erledigt
      </button>
    </div>
  )
}
