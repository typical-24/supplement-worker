"use client"

import type { Portion } from "@/lib/supplements"

interface HeroCardProps {
  portion: Portion
  portionIndex: number
  completedCount: number
}

export function HeroCard({ portion, portionIndex, completedCount }: HeroCardProps) {
  const total = portion.supplements.length
  const open = total - completedCount

  return (
    <div className="px-5 pb-4 pt-1">
      <div className="glass-light relative overflow-hidden rounded-3xl p-6">
        {/* Top shine line */}
        <div 
          className="absolute left-0 right-0 top-0 h-px opacity-90"
          style={{ 
            background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.34), transparent)' 
          }}
        />
        
        {/* Glow orb */}
        <div 
          className="pointer-events-none absolute -right-12 -top-16 h-48 w-48 rounded-full blur-lg"
          style={{ 
            background: 'radial-gradient(circle, rgba(74, 222, 128, 0.24) 0%, rgba(34, 197, 94, 0.14) 42%, transparent 70%)' 
          }}
        />
        
        <div className="relative">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <div className="mb-1 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
                PORTION {portionIndex + 1}
              </div>
              <div className="text-2xl font-extrabold leading-tight tracking-tight text-foreground">
                {portion.name}
              </div>
              <div className="mt-1 font-mono text-xs text-white/70">
                {portion.time} Uhr
              </div>
            </div>
            <div 
              className="glass whitespace-nowrap rounded-full px-3 py-1.5 text-[11px] font-bold tracking-wide text-white"
            >
              {total} Supps
            </div>
          </div>
          
          <div className="flex gap-4 border-t border-white/8 pt-4">
            <div className="flex-1 text-center">
              <div 
                className="font-mono text-xl font-extrabold"
                style={{ 
                  color: '#4ade80',
                  textShadow: '0 0 12px rgba(74, 222, 128, 0.22)'
                }}
              >
                {total}
              </div>
              <div className="mt-0.5 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
                Gesamt
              </div>
            </div>
            <div className="w-px bg-white/8" />
            <div className="flex-1 text-center">
              <div 
                className="font-mono text-xl font-extrabold"
                style={{ 
                  color: '#4ade80',
                  textShadow: '0 0 12px rgba(74, 222, 128, 0.22)'
                }}
              >
                {completedCount}
              </div>
              <div className="mt-0.5 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
                Erledigt
              </div>
            </div>
            <div className="w-px bg-white/8" />
            <div className="flex-1 text-center">
              <div 
                className="font-mono text-xl font-extrabold"
                style={{ 
                  color: '#4ade80',
                  textShadow: '0 0 12px rgba(74, 222, 128, 0.22)'
                }}
              >
                {open}
              </div>
              <div className="mt-0.5 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
                Offen
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
