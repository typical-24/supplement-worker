"use client"

import { X } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Supplement } from "@/lib/supplements"

interface InfoSheetProps {
  supplement: Supplement | null
  isOpen: boolean
  onClose: () => void
}

export function InfoSheet({ supplement, isOpen, onClose }: InfoSheetProps) {
  if (!supplement) return null

  return (
    <>
      {/* Overlay */}
      <div 
        className={cn(
          "fixed inset-0 z-50 transition-opacity duration-300",
          isOpen ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0"
        )}
        style={{
          background: 'rgba(5, 15, 5, 0.68)',
          backdropFilter: 'blur(10px)',
          WebkitBackdropFilter: 'blur(10px)'
        }}
        onClick={onClose}
      />
      
      {/* Sheet */}
      <div 
        className={cn(
          "fixed bottom-0 left-1/2 z-50 w-full max-w-md overflow-y-auto rounded-t-3xl border-t border-white/14 transition-transform duration-400",
          isOpen ? "translate-y-0" : "translate-y-full"
        )}
        style={{
          transform: `translateX(-50%) translateY(${isOpen ? '0' : '100%'})`,
          background: 'linear-gradient(180deg, rgba(255,255,255,0.09), rgba(255,255,255,0.03)), linear-gradient(180deg, rgba(20, 40, 20, 0.94), rgba(15, 30, 15, 0.94))',
          backdropFilter: 'blur(24px) saturate(1.18)',
          WebkitBackdropFilter: 'blur(24px) saturate(1.18)',
          maxHeight: '85vh',
          padding: '0 20px calc(40px + env(safe-area-inset-bottom))',
          boxShadow: '0 -12px 30px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.10)'
        }}
      >
        {/* Handle */}
        <div className="mx-auto my-4 h-1 w-9 rounded-full bg-white/16" />
        
        <div className="pb-6">
          <div className="mb-1.5 text-2xl font-extrabold tracking-tight">
            {supplement.name}
          </div>
          <div className="mb-5 font-mono text-xs tracking-wide text-muted-foreground">
            FOCUS: {supplement.focus}
          </div>
          <div className="mb-6 text-sm leading-relaxed text-white/70">
            {supplement.description}
          </div>
          
          <div className="space-y-0">
            <div className="flex items-center justify-between border-b border-white/8 py-3.5">
              <span className="font-mono text-xs tracking-wide text-muted-foreground">EVIDENCE</span>
              <span className="text-sm font-semibold">{supplement.evidence}</span>
            </div>
            <div className="flex items-center justify-between border-b border-white/8 py-3.5">
              <span className="font-mono text-xs tracking-wide text-muted-foreground">FOCUS</span>
              <span className="text-sm font-semibold">{supplement.focus}</span>
            </div>
          </div>
          
          {supplement.examineUrl && (
            <a
              href={supplement.examineUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 block w-full rounded-2xl px-3.5 py-3.5 text-center text-sm font-bold text-white transition-transform active:scale-98"
              style={{
                background: 'linear-gradient(135deg, #4ade80 0%, #22c55e 48%, #16a34a 100%)',
                boxShadow: '0 0 18px rgba(74, 222, 128, 0.32), 0 0 30px rgba(34, 197, 94, 0.16)'
              }}
            >
              Auf Examine.com ansehen
            </a>
          )}
        </div>
      </div>
    </>
  )
}
