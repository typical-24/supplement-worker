"use client"

import { cn } from "@/lib/utils"
import type { Portion } from "@/lib/supplements"

interface PortionTabsProps {
  portions: Portion[]
  activePortionId: string
  onPortionChange: (id: string) => void
  completedSupplements: Set<string>
}

export function PortionTabs({ 
  portions, 
  activePortionId, 
  onPortionChange,
  completedSupplements 
}: PortionTabsProps) {
  
  const isPortionComplete = (portion: Portion) => {
    return portion.supplements.every(s => completedSupplements.has(s.id))
  }

  return (
    <div className="overflow-hidden pb-1">
      <div className="flex gap-2 overflow-x-auto px-5 pb-3 pt-1 scrollbar-hide">
        {portions.map((portion) => {
          const isActive = portion.id === activePortionId
          const isComplete = isPortionComplete(portion)
          
          return (
            <button
              key={portion.id}
              onClick={() => onPortionChange(portion.id)}
              className={cn(
                "glass flex-shrink-0 snap-start whitespace-nowrap rounded-2xl px-4 py-2.5 transition-all active:scale-95",
                isActive && "glass-active"
              )}
            >
              <div className="flex items-center gap-1.5">
                <span className={cn(
                  "text-[11px] font-bold uppercase tracking-wide",
                  isActive ? "text-white" : "text-white/70"
                )}>
                  {portion.name}
                </span>
                {isComplete && (
                  <span 
                    className="h-1.5 w-1.5 rounded-full bg-white"
                    style={{ boxShadow: '0 0 8px rgba(255,255,255,0.6)' }}
                  />
                )}
              </div>
              <div className={cn(
                "mt-0.5 font-mono text-[9px]",
                isActive ? "text-white/80" : "text-muted-foreground"
              )}>
                {portion.time} Uhr
              </div>
            </button>
          )
        })}
      </div>
    </div>
  )
}
