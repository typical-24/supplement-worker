"use client"

interface ProgressBarProps {
  done: number
  total: number
}

export function ProgressBar({ done, total }: ProgressBarProps) {
  const percentage = total > 0 ? (done / total) * 100 : 0

  return (
    <div className="px-5 pb-5 pt-1">
      <div className="mb-2.5 flex items-baseline justify-between">
        <span className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
          Tages-Fortschritt
        </span>
        <span>
          <span 
            className="font-mono text-xl font-extrabold"
            style={{ 
              color: '#4ade80',
              textShadow: '0 0 12px rgba(74, 222, 128, 0.22)'
            }}
          >
            {done}
          </span>
          <span className="text-sm font-normal text-muted-foreground"> / {total}</span>
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-white/8 shadow-inner">
        <div 
          className="h-full rounded-full transition-all duration-500 ease-out"
          style={{
            width: `${percentage}%`,
            background: 'linear-gradient(90deg, #4ade80 0%, #22c55e 50%, #16a34a 100%)',
            boxShadow: '0 0 10px rgba(74, 222, 128, 0.45), 0 0 18px rgba(34, 197, 94, 0.18)'
          }}
        />
      </div>
    </div>
  )
}
