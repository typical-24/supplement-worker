"use client"

import { useState } from "react"
import { Check, Info, ExternalLink } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Supplement } from "@/lib/supplements"

interface SupplementCardProps {
  supplement: Supplement
  isDone: boolean
  onToggle: () => void
  onShowInfo: () => void
}

const focusColors: Record<string, string> = {
  AMPK: "border-orange-400/30 bg-gradient-to-r from-orange-400/20 to-pink-400/15",
  mTOR: "border-purple-400/30 bg-gradient-to-r from-purple-400/20 to-blue-400/15",
  NAD: "border-amber-400/30 bg-gradient-to-r from-amber-400/20 to-pink-400/15",
  Detox: "border-fuchsia-400/30 bg-gradient-to-r from-fuchsia-400/20 to-pink-400/15",
  Stress: "border-pink-400/30 bg-gradient-to-r from-pink-400/20 to-purple-400/15",
  Cardio: "border-orange-400/30 bg-gradient-to-r from-orange-400/20 to-red-400/15",
  Sleep: "border-violet-400/30 bg-gradient-to-r from-violet-400/20 to-pink-400/15",
  Immune: "border-emerald-400/30 bg-gradient-to-r from-emerald-400/20 to-blue-400/15",
  neutral: "border-slate-400/20 bg-gradient-to-r from-purple-400/15 to-white/5"
}

export function SupplementCard({ supplement, isDone, onToggle, onShowInfo }: SupplementCardProps) {
  const [isFlashing, setIsFlashing] = useState(false)

  const handleClick = () => {
    setIsFlashing(true)
    setTimeout(() => setIsFlashing(false), 150)
    onToggle()
  }

  const focusClass = focusColors[supplement.focus] || focusColors.neutral

  return (
    <div 
      onClick={handleClick}
      className={cn(
        "glass-light relative mb-3 cursor-pointer overflow-hidden rounded-2xl p-4 transition-all active:scale-[0.985]",
        isDone && "opacity-70"
      )}
    >
      {/* Left accent bar */}
      <div 
        className={cn(
          "absolute bottom-3 left-0 top-3 w-1.5 rounded-r-lg transition-opacity",
          isDone ? "opacity-100" : "opacity-90"
        )}
        style={{
          background: 'linear-gradient(180deg, #4ade80 0%, #22c55e 45%, #16a34a 100%)',
          boxShadow: isDone 
            ? '0 0 12px rgba(74, 222, 128, 0.85), 0 0 24px rgba(34, 197, 94, 0.60)'
            : '0 0 10px rgba(74, 222, 128, 0.7), 0 0 22px rgba(34, 197, 94, 0.48)'
        }}
      />
      
      {/* Flash overlay */}
      <div 
        className={cn(
          "pointer-events-none absolute inset-0 rounded-inherit transition-opacity duration-150",
          isFlashing ? "opacity-20" : "opacity-0"
        )}
        style={{
          background: 'linear-gradient(135deg, rgba(74, 222, 128, 0.14), rgba(34, 197, 94, 0.16), rgba(22, 163, 74, 0.12))'
        }}
      />
      
      <div className="flex items-start gap-3">
        {/* Checkbox */}
        <div 
          className={cn(
            "mt-0.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-md border-[1.5px] transition-all",
            isDone 
              ? "border-white/10" 
              : "border-white/20 bg-white/5"
          )}
          style={isDone ? {
            background: 'linear-gradient(135deg, #4ade80, #22c55e 48%, #16a34a 100%)',
            boxShadow: '0 0 12px rgba(74, 222, 128, 0.28), 0 0 18px rgba(34, 197, 94, 0.20)'
          } : {}}
        >
          <Check 
            className={cn(
              "h-3 w-3 text-white transition-all",
              isDone ? "scale-100 opacity-100" : "scale-0 opacity-0"
            )}
          />
        </div>
        
        {/* Content */}
        <div className="min-w-0 flex-1">
          <div className={cn(
            "text-sm font-bold text-foreground transition-all",
            isDone && "text-muted-foreground line-through"
          )}>
            {supplement.name}
          </div>
          <div className={cn(
            "mt-0.5 text-xs leading-relaxed text-white/70 transition-opacity",
            isDone && "opacity-45"
          )}>
            {supplement.description}
          </div>
          
          {/* Badges */}
          <div className="mt-2.5 flex flex-wrap gap-1.5">
            <span className={cn(
              "rounded-full border-[0.5px] px-2 py-0.5 font-mono text-[10px] font-semibold tracking-wide text-white",
              focusClass
            )}>
              {supplement.focus}
            </span>
            <span className={cn(
              "rounded-full border-[0.5px] border-white/15 bg-gradient-to-r from-white/10 to-white/5 px-2 py-0.5 font-mono text-[11px] font-semibold text-white transition-colors",
              isDone && "border-white/6 text-muted-foreground"
            )}>
              {supplement.evidence}
            </span>
          </div>
        </div>
        
        {/* Action buttons */}
        <div className="flex flex-shrink-0 items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
          <button 
            onClick={onShowInfo}
            className="glass flex h-7 w-7 items-center justify-center rounded-lg transition-all hover:bg-white/10 hover:-translate-y-0.5"
          >
            <Info className="h-3 w-3 text-white/70" />
          </button>
          {supplement.examineUrl && (
            <a 
              href={supplement.examineUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="glass flex h-7 w-7 items-center justify-center rounded-lg transition-all hover:bg-white/10 hover:-translate-y-0.5"
            >
              <ExternalLink className="h-3 w-3 text-white/70" />
            </a>
          )}
        </div>
      </div>
    </div>
  )
}
