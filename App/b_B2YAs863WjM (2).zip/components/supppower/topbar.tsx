"use client"

import { Clipboard, Zap } from "lucide-react"

interface TopbarProps {
  onShowSummary: () => void
}

export function Topbar({ onShowSummary }: TopbarProps) {
  return (
    <div className="flex items-center justify-between px-5 pb-4 pt-14">
      <div className="flex items-center gap-3">
        <div 
          className="flex h-9 w-9 items-center justify-center rounded-xl text-white"
          style={{
            background: 'linear-gradient(135deg, #4ade80, #22c55e 58%, #16a34a)',
            boxShadow: '0 0 22px rgba(74, 222, 128, 0.35), 0 0 38px rgba(34, 197, 94, 0.18)'
          }}
        >
          <Zap className="h-4 w-4" />
        </div>
        <div>
          <div className="text-sm font-bold tracking-wide text-foreground">SUPPPOWER OS</div>
          <div className="font-mono text-[10px] tracking-widest text-muted-foreground">BIOHACKING CONSOLE</div>
        </div>
      </div>
      <div className="flex gap-2">
        <button 
          onClick={onShowSummary}
          className="glass flex h-10 w-10 items-center justify-center rounded-xl transition-all hover:bg-white/10 active:scale-95"
          title="Summary"
        >
          <Clipboard className="h-4 w-4 text-white/70" />
        </button>
      </div>
    </div>
  )
}
