export interface Supplement {
  id: string
  name: string
  description: string
  focus: string
  evidence: string
  examineUrl?: string
}

export interface Portion {
  id: string
  name: string
  time: string
  supplements: Supplement[]
}

export const portions: Portion[] = [
  {
    id: "morning",
    name: "Morgen",
    time: "07:00",
    supplements: [
      {
        id: "nmn",
        name: "NMN",
        description: "500mg - NAD+ Booster fur Zellenergie",
        focus: "NAD",
        evidence: "A",
        examineUrl: "https://examine.com/supplements/nmn/"
      },
      {
        id: "resveratrol",
        name: "Resveratrol",
        description: "500mg - Aktiviert Sirtuine, mit Fett nehmen",
        focus: "AMPK",
        evidence: "A",
        examineUrl: "https://examine.com/supplements/resveratrol/"
      },
      {
        id: "omega3",
        name: "Omega-3",
        description: "2g EPA/DHA - Entzundungshemmend",
        focus: "Cardio",
        evidence: "A",
        examineUrl: "https://examine.com/supplements/fish-oil/"
      },
      {
        id: "vitd",
        name: "Vitamin D3 + K2",
        description: "5000 IU D3 + 200mcg K2 MK-7",
        focus: "Immune",
        evidence: "A",
        examineUrl: "https://examine.com/supplements/vitamin-d/"
      },
      {
        id: "creatine",
        name: "Kreatin",
        description: "5g - Kognitiv & Muskelkraft",
        focus: "mTOR",
        evidence: "A",
        examineUrl: "https://examine.com/supplements/creatine/"
      }
    ]
  },
  {
    id: "midday",
    name: "Mittag",
    time: "12:00",
    supplements: [
      {
        id: "berberine",
        name: "Berberin",
        description: "500mg - AMPK-Aktivator, Blutzucker",
        focus: "AMPK",
        evidence: "A",
        examineUrl: "https://examine.com/supplements/berberine/"
      },
      {
        id: "quercetin",
        name: "Quercetin",
        description: "500mg - Senolytisch, Antioxidant",
        focus: "Detox",
        evidence: "B",
        examineUrl: "https://examine.com/supplements/quercetin/"
      },
      {
        id: "curcumin",
        name: "Curcumin",
        description: "500mg - Mit Piperin fur Absorption",
        focus: "Detox",
        evidence: "A",
        examineUrl: "https://examine.com/supplements/curcumin/"
      }
    ]
  },
  {
    id: "evening",
    name: "Abend",
    time: "18:00",
    supplements: [
      {
        id: "glycine",
        name: "Glycin",
        description: "3g - Kollagen & Schlafqualitat",
        focus: "Sleep",
        evidence: "B",
        examineUrl: "https://examine.com/supplements/glycine/"
      },
      {
        id: "ashwagandha",
        name: "Ashwagandha",
        description: "600mg KSM-66 - Stressreduktion",
        focus: "Stress",
        evidence: "A",
        examineUrl: "https://examine.com/supplements/ashwagandha/"
      }
    ]
  },
  {
    id: "night",
    name: "Nacht",
    time: "22:00",
    supplements: [
      {
        id: "magnesium",
        name: "Magnesium Glycinat",
        description: "400mg - Schlaf & Muskelrelaxation",
        focus: "Sleep",
        evidence: "A",
        examineUrl: "https://examine.com/supplements/magnesium/"
      },
      {
        id: "melatonin",
        name: "Melatonin",
        description: "0.5mg - Circadianer Rhythmus",
        focus: "Sleep",
        evidence: "A",
        examineUrl: "https://examine.com/supplements/melatonin/"
      }
    ]
  }
]

export function getTotalSupplements(): number {
  return portions.reduce((acc, p) => acc + p.supplements.length, 0)
}
